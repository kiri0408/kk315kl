from dotenv import load_dotenv
from strands import Agent
import tool_test
import tool_postgre
import sys
import os

# .envファイルから環境変数を読み込む
load_dotenv(dotenv_path="C:/.secret/.env")
model=os.getenv("MODEL")

async def agent1_streaming(question: str):
    """
    agentの実行過程をストリーミングで返す非同期ジェネレータ 
    """
    import queue
    import threading
    
    # スレッド間通信用のキュー
    output_queue = queue.Queue()
    original_stdout = sys.stdout
    
    class StreamCapture:
        def __init__(self, original_stream, queue):
            self.original_stream = original_stream
            self.queue = queue
            
        def write(self, text):
            # 元の標準出力にも書き込む
            self.original_stream.write(text)
            self.original_stream.flush()
            
            # キューにも送る
            self.queue.put(("output", text))
            return len(text)
        
        def flush(self):
            self.original_stream.flush()
    
    # 標準出力をキャプチャ開始
    sys.stdout = StreamCapture(original_stdout, output_queue)
    
    try:
        # agentを別スレッドで実行
        def run_agent():
            try:
                agent = Agent(
                    model=model,
                    tools=[tool_test.counter, tool_test.read_cell_value, tool_postgre.search_usermaster, tool_test.read_meibo]
                )
                result = agent(question)
                # 完了を示すマーカーをキューに送る
                output_queue.put(("complete", str(result)))
            except Exception as e:
                output_queue.put(("error", str(e)))
        
        # agentを別スレッドで開始
        thread = threading.Thread(target=run_agent)
        thread.start()
        
        # 出力をリアルタイムで取得してyield
        while True:
            try:
                # タイムアウト付きでキューから取得
                msg_type, content = output_queue.get(timeout=0.1)
                
                if msg_type == "output":
                    # 試行過程の出力
                    yield {"type": "progress", "content": content}
                elif msg_type == "complete":
                    # agent実行完了
                    yield {"type": "result", "content": content}
                    break
                elif msg_type == "error":
                    # エラー発生
                    yield {"type": "error", "content": content}
                    break
                    
            except queue.Empty:
                # タイムアウト時は継続
                if not thread.is_alive():
                    # スレッドが終了している場合は最後のメッセージを確認
                    try:
                        msg_type, content = output_queue.get_nowait()
                        if msg_type == "complete":
                            yield {"type": "result", "content": content}
                        elif msg_type == "error":
                            yield {"type": "error", "content": content}
                    except queue.Empty:
                        pass
                    break
                continue
        
        # スレッドの終了を待つ
        thread.join()
    
    finally:
        # 標準出力を元に戻す
        sys.stdout = original_stdout


