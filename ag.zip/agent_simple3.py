"""
https://strandsagents.com/latest/documentation/docs/user-guide/concepts/tools/mcp-tools/
"""

from mcp import stdio_client, StdioServerParameters
from strands import Agent
from strands.tools.mcp import MCPClient
from dotenv import load_dotenv
from strands import Agent
import os
from strands_tools import http_request, calculator, current_time 

load_dotenv(dotenv_path="C:/.secret/.env")

# stdio_mcp_client は uvx コマンドを使い、MCPサーバーを起動する。
stdio_mcp_client = MCPClient(lambda: stdio_client(
    StdioServerParameters(
        command="uvx", 
        args=[
            "--from", 
            "awslabs.aws-documentation-mcp-server@latest", 
            "awslabs.aws-documentation-mcp-server.exe"
        ]
    )
))

# filesystem_mcp_client は直接バッチファイルを実行し、ファイルシステム用 MCPサーバーを起動する。
# コマンドファイルを直接指定し、引数に監視するフォルダパスを渡す。
filesystem_mcp_client = MCPClient(lambda: stdio_client(
    StdioServerParameters(
        command="C:\\Users\\arwml\\AppData\\Roaming\\npm\\mcp-server-filesystem.cmd",
        args=[
            "C:/tmp/test_folder1", "C:/tmp/test_folder2"
        ]
    )
))

system_prompt = """
- あなたは、優秀なアシスタントです。
- ここは長崎県です。
- 必要に応じて、行動の最初に現在日時をしっかり確認すること。
- ファイルを読み書きするフォルダは、 C:/tmp/test_folder1/ です。
- 話し方は、ペットの犬のような話しかたにして。絵文字もほどよく使って。
- 必要に応じて、天気予報データは、https://www.jma.go.jp/bosai/forecast/data/forecast/420000.json  から取得して。
- レポート作成時は、基本的にHTML形式とし、ファイル名は、Report_YYYYMMDD_HHMMSS.html (YYYYMMDD_HHMMSSは作成日時)としてください。  
- レポート作成時は、全体的な概要まとめを最初に記載して。
- 過去のレポートも フォルダ C:/tmp/test_folder1/ に、 Report_YYYYMMDD_HHMMSS.html (YYYYMMDD_HHMMSSは作成日時) で残っているので必要に応じて参照して。 
"""

prompt = "やってほしいことリスト.txt をみて、やっといて。"
prompt = "さっきのレポート  Report_20250928_171433.html だけど、気象情報の横に、予定もくっつけて一つの表にした、新たなレポートを作成して。"
prompt = 'aaa.txtの内容を読み込んで、表示して。'
prompt = '関係者のメールアドレスをﾘｽﾄｱｯﾌﾟして'


print('Agent処理開始')
with stdio_mcp_client, filesystem_mcp_client:  # MCPサーバーを起動

    tools = stdio_mcp_client.list_tools_sync() + filesystem_mcp_client.list_tools_sync() 
    tools += [http_request, calculator, current_time ]

    # エージェントを作成
    agent = Agent(model=os.getenv("MODEL"),      # モデルのセット
                system_prompt=system_prompt,     # システムプロンプトのセット
                tools=tools,                     # ツールのセット
                load_tools_from_directory=True   # ./tools のpython関数を使う設定
                )
    
    # エージェントを実行
    agent(prompt)
