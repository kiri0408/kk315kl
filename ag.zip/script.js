class ChatApp {
    constructor() {
        this.apiUrl = 'http://localhost:5000';
        this.isStreaming = false;
        this.currentStreamingMessage = null;
        
        this.initializeElements();
        this.bindEvents();
        this.checkServerStatus();
        this.setWelcomeTime();
    }

    initializeElements() {
        this.chatMessages = document.getElementById('chatMessages');
        this.messageInput = document.getElementById('messageInput');
        this.sendButton = document.getElementById('sendButton');
        this.streamingMode = document.getElementById('streamingMode');
        this.charCount = document.getElementById('charCount');
        this.statusDot = document.getElementById('statusDot');
        this.statusText = document.getElementById('statusText');
        this.loadingOverlay = document.getElementById('loadingOverlay');
        this.errorModal = document.getElementById('errorModal');
        this.errorMessage = document.getElementById('errorMessage');
        this.errorClose = document.getElementById('errorClose');
    }

    bindEvents() {
        // 送信ボタンクリック
        this.sendButton.addEventListener('click', () => this.sendMessage());
        
        // Enterキーで送信（Shift+Enterで改行）
        this.messageInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // 入力内容の変化を監視
        this.messageInput.addEventListener('input', () => {
            this.updateCharCount();
            this.updateSendButton();
            this.autoResize();
        });
        
        // エラーモーダルを閉じる
        this.errorClose.addEventListener('click', () => {
            this.hideError();
        });
        
        // モーダル背景クリックで閉じる
        this.errorModal.addEventListener('click', (e) => {
            if (e.target === this.errorModal) {
                this.hideError();
            }
        });
    }

    setWelcomeTime() {
        const welcomeTimeElement = document.getElementById('welcomeTime');
        if (welcomeTimeElement) {
            welcomeTimeElement.textContent = this.formatTime(new Date());
        }
    }

    updateCharCount() {
        const count = this.messageInput.value.length;
        this.charCount.textContent = count;
        
        if (count > 900) {
            this.charCount.style.color = '#ef4444';
        } else if (count > 800) {
            this.charCount.style.color = '#f59e0b';
        } else {
            this.charCount.style.color = '#9ca3af';
        }
    }

    updateSendButton() {
        const hasText = this.messageInput.value.trim().length > 0;
        this.sendButton.disabled = !hasText || this.isStreaming;
    }

    autoResize() {
        this.messageInput.style.height = 'auto';
        this.messageInput.style.height = Math.min(this.messageInput.scrollHeight, 120) + 'px';
    }

    async checkServerStatus() {
        try {
            const response = await fetch(`${this.apiUrl}/health`);
            if (response.ok) {
                this.updateStatus('connected', 'オンライン');
            } else {
                this.updateStatus('error', 'サーバーエラー');
            }
        } catch (error) {
            this.updateStatus('error', 'オフライン');
        }
    }

    updateStatus(status, text) {
        this.statusDot.className = `status-dot ${status}`;
        this.statusText.textContent = text;
    }

    async sendMessage() {
        const message = this.messageInput.value.trim();
        if (!message || this.isStreaming) return;

        // ユーザーメッセージを表示
        this.addMessage(message, 'user');
        
        // 入力フィールドをクリア
        this.messageInput.value = '';
        this.updateCharCount();
        this.updateSendButton();
        this.autoResize();

        // 常にストリーミングモードで送信
        await this.sendStreamingMessage(message);
    }

    async sendNormalMessage(message) {
        this.showLoading();
        this.isStreaming = true;
        this.updateSendButton();

        try {
            const response = await fetch(`${this.apiUrl}/api/chat`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message })
            });

            const data = await response.json();

            if (data.status === 'success') {
                this.addMessage(data.response, 'bot');
            } else {
                this.showError(data.error || 'エラーが発生しました');
            }
        } catch (error) {
            this.showError(`通信エラー: ${error.message}`);
        } finally {
            this.hideLoading();
            this.isStreaming = false;
            this.updateSendButton();
        }
    }

    async sendStreamingMessage(message) {
        this.isStreaming = true;
        this.updateSendButton();
        this.updateStatus('connecting', '処理中...');

        // ストリーミング用のボットメッセージを作成
        this.currentStreamingMessage = this.addMessage('', 'bot', true);

        try {
            const response = await fetch(`${this.apiUrl}/api/chat/stream`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message })
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop(); // 最後の不完全な行を保持

                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            this.handleStreamingData(data);
                        } catch (e) {
                            console.warn('JSON parse error:', e, line);
                        }
                    }
                }
            }
        } catch (error) {
            this.showError(`ストリーミングエラー: ${error.message}`);
            if (this.currentStreamingMessage) {
                this.currentStreamingMessage.remove();
                this.currentStreamingMessage = null;
            }
        } finally {
            this.isStreaming = false;
            this.updateSendButton();
            this.updateStatus('connected', 'オンライン');
            
            // ストリーミング表示を終了
            if (this.currentStreamingMessage) {
                this.currentStreamingMessage.classList.remove('streaming-message');
                this.currentStreamingMessage = null;
            }
        }
    }

    handleStreamingData(data) {
        if (!this.currentStreamingMessage) return;

        const messageText = this.currentStreamingMessage.querySelector('.message-text');
        
        switch (data.type) {
            case 'progress':
                // 進行状況をリアルタイムで表示
                messageText.textContent += data.content;
                this.scrollToBottom();
                break;
                
            case 'result':
                // 最終結果を表示
                messageText.textContent = data.content;
                this.currentStreamingMessage.classList.remove('streaming-message');
                this.scrollToBottom();
                break;
                
            case 'error':
                // エラーを表示
                this.showError(data.content);
                if (this.currentStreamingMessage) {
                    this.currentStreamingMessage.remove();
                    this.currentStreamingMessage = null;
                }
                break;
        }
    }

    addMessage(text, sender, isStreaming = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message${isStreaming ? ' streaming-message' : ''}`;

        const avatar = document.createElement('div');
        avatar.className = 'message-avatar';
        avatar.textContent = sender === 'user' ? '👤' : '🤖';

        const content = document.createElement('div');
        content.className = 'message-content';

        const messageText = document.createElement('div');
        messageText.className = 'message-text';
        messageText.textContent = text;

        const messageTime = document.createElement('div');
        messageTime.className = 'message-time';
        messageTime.textContent = this.formatTime(new Date());

        content.appendChild(messageText);
        content.appendChild(messageTime);
        messageDiv.appendChild(avatar);
        messageDiv.appendChild(content);

        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();

        return messageDiv;
    }

    formatTime(date) {
        return date.toLocaleTimeString('ja-JP', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    scrollToBottom() {
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
    }

    showLoading() {
        this.loadingOverlay.classList.add('show');
    }

    hideLoading() {
        this.loadingOverlay.classList.remove('show');
    }

    showError(message) {
        this.errorMessage.textContent = message;
        this.errorModal.classList.add('show');
    }

    hideError() {
        this.errorModal.classList.remove('show');
    }
}

// アプリケーション初期化
document.addEventListener('DOMContentLoaded', () => {
    new ChatApp();
});

// サービスワーカー登録（オフライン対応）
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}
