from strands import tool

@tool
def read_file(path: str) -> str:
    """
    指定されたファイルパスのテキストファイルを読み込み、その内容を文字列として返す関数。
    テキストファイルの高速読み込み。

    Args:
        path (str): 読み込むファイルのパス（UTF-8エンコーディングのテキストファイルを想定）

    Returns:
        str: ファイルの内容を文字列として返す
    """
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


if __name__ == "__main__":
    str1 = read_file('C:/tmp/test_folder1/aaa.txt')
    print(str1)