import win32com.client
from datetime import datetime, timedelta, timezone
from strands import tool
import json

outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
calendar = outlook.GetDefaultFolder(9)  # 9は予定表フォルダ
items = calendar.Items
items.Sort("[Start]")

# 予定の範囲を設定
now = datetime.now()
days = 5
if days >= 0:
    start_filter = now
    end_filter = now + timedelta(days=days)
else:
    start_filter = now + timedelta(days=days)
    end_filter = now


# 予定表のフィルタリング用の文字列を作成（Outlookのフィルタ形式）
# 例: "[Start] >= '2025-09-28 00:00' AND [Start] <= '2025-10-01 23:59'"
start_str = start_filter.strftime("%m/%d/%Y %H:%M %p")
end_str = end_filter.strftime("%m/%d/%Y %H:%M %p")
restriction = "[Start] >= '{}' AND [Start] <= '{}'".format(start_str, end_str)
restricted_items = items.Restrict(restriction)

schedule_list = []
for appointment in restricted_items:
    try:
        start_time = appointment.Start
        end_time = appointment.End
        subject = appointment.Subject
        location = appointment.Location if hasattr(appointment, "Location") else ""
        body = appointment.Body if hasattr(appointment, "Body") else ""

        schedule_list.append({
            "Subject": subject,
            "Start": start_time.strftime("%Y-%m-%d %H:%M:%S"),
            "End": end_time.strftime("%Y-%m-%d %H:%M:%S"),
            "Location": location,
            "Body": body[:1000]  # 長すぎる場合は1000文字まで
        })
    except Exception:
        continue

# 開始日時でソート（念のため）
schedule_list.sort(key=lambda x: x["Start"])

yotei =  json.dumps(schedule_list, ensure_ascii=False)
print('outlook予定読み込み完了')


@tool
def get_outlook_schedule():
    """
    Outlookの予定表から予定を取得する。
    引数:

    戻り値:
        str: JSON形式の予定リスト文字列。各予定は件名(Subject)、開始日時(Start)、終了日時(End)、場所(Location)、説明(Body)を含む。
    """
    print('OUTLOOKからの予定を取得') 
    return yotei




if __name__ == "__main__":
    import sys
    try:
        days = int(sys.argv[1])
    except (IndexError, ValueError):
        days = 3  # デフォルト3日間

    schedules_json = get_outlook_schedule()
    schedules = json.loads(schedules_json)
    for s in schedules:
        print(f"件名: {s['Subject']}")
        print(f"開始: {s['Start']}")
        print(f"終了: {s['End']}")
        print(f"場所: {s['Location']}")
        print(f"説明: {s['Body']}")
        print("-" * 40)
    print("処理完了")
