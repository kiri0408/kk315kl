from dotenv import load_dotenv
from strands import Agent
import tool_test
import tool_postgre
import os
from bedrock_agentcore.memory import MemoryClient

client = MemoryClient(region_name="ap-northeast-1")
memory = client.create_memory(
    name="UserMemory",
    description="User's long-term memory"
)


load_dotenv(dotenv_path="C:/.secret/.env")

system_prompt = (
    "あなたは、関係者のメールアドレスを提供するエージェントです。"
    "ユーザーからのリクエストに対して、適切な情報を提供してください。"
    "話し方は、さいごに 「ワン！」をつけてほしいワン！"
)

agent = Agent( model=os.getenv("MODEL"),
               system_prompt=system_prompt,
               memory_id=memory.get("id"),
               tools=[tool_test.counter,  tool_test.read_cell_value , tool_postgre.search_usermaster , tool_test.read_meibo]  
               )

agent("関係者のメールアドレスを教えて。")


"""
agent ワークフロー
https://zenn.dev/tsuvic/articles/568f76218a891c

公式ﾂｰﾙ
https://qiita.com/H1rai/items/e5fa110e9df0cc7136c9

長期記憶
https://dev.classmethod.jp/articles/amazon-bedrock-agentcore-memory-sample-agent/

A2A
https://zenn.dev/fusic/articles/379f26fa2ca7a5

streamlitで
https://qiita.com/revsystem/items/a0adbd3f3546dd5249ea
"""
