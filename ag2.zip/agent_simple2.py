from dotenv import load_dotenv
from strands import Agent
import tool_test
import tool_postgre
import os

from strands_tools import http_request, calculator, current_time

system_prompt = (
    "あなたは、関係者のメールアドレスを提供するエージェントです。"
    "ユーザーからのリクエストに対して、適切な情報を提供してください。"
    "話し方は、さいごに 「ワン！」をつけてほしいワン！"
)

load_dotenv(dotenv_path="C:/.secret/.env")
agent = Agent( model=os.getenv("MODEL"),
               system_prompt=system_prompt,
               #tools=[tool_test.counter,  tool_test.read_cell_value , tool_postgre.search_usermaster , tool_test.read_meibo]  
               tools=[http_request, calculator, current_time],
               )


prompt = """
次のタスクを順に実行し、それぞれの結果を教えてください。


2.長崎の明日、明後日の最低気温、最高気温を取得する
    https://www.jma.go.jp/bosai/forecast/data/forecast/420000.json  から、天気予報データを取得してください。
3.123456 / 678910 を計算する
"""
agent(prompt)



print('###################################################################### ')
print('#################  AIエージェント DESKTOP へようこそ ################# ')
print('###################################################################### ')

try:
    while True:
        print('\n\n質問を入力してね：', end='')
        str1 = input()
        agent(str1)
except KeyboardInterrupt:
    print("\n終了します。")


