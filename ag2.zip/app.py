from flask import Flask, request, jsonify, Response, send_from_directory
from flask_cors import CORS
import json
import asyncio
import threading
import os
from agent import agent1, agent1_streaming

app = Flask(__name__)
CORS(app)  # フロントエンドからのアクセスを許可



@app.route('/api/chat/stream', methods=['POST'])
def chat_stream():
    """ストリーミングチャット機能"""
    try:
        data = request.get_json()
        question = data.get('message', '')
        
        if not question:
            return jsonify({'error': 'メッセージが空です'}), 400
        
        def generate():
            """Server-Sent Eventsでストリーミング応答を生成"""
            try:
                # 非同期関数を同期的に実行
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                async def run_streaming():
                    async for chunk in agent1_streaming(question):
                        yield f"data: {json.dumps(chunk, ensure_ascii=False)}\n\n"
                
                # 非同期ジェネレータを同期的に実行
                async_gen = run_streaming()
                while True:
                    try:
                        chunk = loop.run_until_complete(async_gen.__anext__())
                        yield chunk
                    except StopAsyncIteration:
                        break
                        
            except Exception as e:
                error_data = {
                    'type': 'error',
                    'content': f'ストリーミングエラー: {str(e)}'
                }
                yield f"data: {json.dumps(error_data, ensure_ascii=False)}\n\n"
            finally:
                loop.close()
        
        return Response(
            generate(),
            mimetype='text/event-stream',
            headers={
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',
                'Access-Control-Allow-Origin': '*'
            }
        )
    
    except Exception as e:
        return jsonify({
            'error': f'エラーが発生しました: {str(e)}',
            'status': 'error'
        }), 500

@app.route('/')
def index():
    """メインページ"""
    return send_from_directory('.', 'index.html')

@app.route('/<path:filename>')
def static_files(filename):
    """静的ファイル（CSS、JS）を提供"""
    return send_from_directory('.', filename)

@app.route('/health', methods=['GET'])
def health_check():
    """ヘルスチェック"""
    return jsonify({'status': 'healthy'})

if __name__ == '__main__':
    print("AIチャットサーバーを起動中...")
    print("URL: http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)
