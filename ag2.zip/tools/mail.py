import win32com.client
from datetime import datetime, timedelta, timezone
from strands import tool
import json

@tool
def get_recent_emails(days=3):
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    inbox = outlook.GetDefaultFolder(6)  # 6 is the index of the inbox folder
    messages = inbox.Items
    messages.Sort("[ReceivedTime]", True)  # Sort by ReceivedTime descending

    cutoff_date = datetime.now(timezone.utc) - timedelta(days=days)
    recent_emails = []

    for message in messages:
        try:
            received_time = message.ReceivedTime
            print(f": メール受信日時: {received_time}  件名：{message.Subject}") 
            if received_time >= cutoff_date:
                body_preview = ""
                try:
                    body = message.Body
                    if body:
                        body_preview = body[:1000]
                except Exception:
                    body_preview = ""

                email_info = {
                    "Subject": message.Subject,
                    "Sender": message.SenderName,
                    "ReceivedTime": received_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "BodyPreview": body_preview
                }
                recent_emails.append(email_info)
            else:
                # Since messages are sorted descending, we can break early
                break
        except Exception:
            # Skip any items that are not mail items or have missing attributes
            continue

    return recent_emails


from strands.tools import tool
import pythoncom
import win32com.client
import threading


def read_outlook():
    pythoncom.CoInitialize()  # STA 初期化
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    inbox = outlook.GetDefaultFolder(6)
    messages = inbox.Items
    messages_list = list(messages)
    subjects = [msg.Subject for msg in messages_list[:5]]
    pythoncom.CoUninitialize()
    return subjects


@tool
def get_outlook_subjects(limit: int = 5):
    """
    Outlookの受信トレイから件名を取得するツール関数。

    引数:
        limit (int): 取得する件名の最大数。デフォルトは5。

    処理:
        - スレッド内でCOMを初期化しOutlookの受信トレイからメッセージを取得。
        - メッセージの件名をlimit件数だけリストに抽出。

    戻り値:
        list: 件名の文字列リスト。
    """
    result = []
    def target():
        nonlocal result
        result = read_outlook()
    t = threading.Thread(target=target)
    t.start()
    t.join()
    return result




if __name__ == "__main__":
    # emails = get_recent_emails(30)
    # for email in emails:
    #     print(f"Subject: {email['Subject']}")
    #     print(f"Sender: {email['Sender']}")
    #     print(f"Received: {email['ReceivedTime']}")
    #     print(f"BodyPreview: {email['BodyPreview']}")
    #     print("-" * 40)
    # print('処理完了')


    str1 = get_outlook_subjects(5)
    print(str1)


"""
OutlookのGetDefaultFolderメソッドで使われるフォルダ番号はMAPIの標準フォルダを示しており、代表的な番号は以下の通りです。
- 3: 送信済みアイテム (Sent Items)
- 4: 削除済みアイテム (Deleted Items)
- 5: 下書き (Drafts)
- 6: 受信トレイ (Inbox)
- 9: 予定表 (Calendar)
- 10: 連絡先 (Contacts)
- 12: ジャーナル (Journal)
- 13: メモ (Notes)
- 14: タスク (Tasks)

"""
