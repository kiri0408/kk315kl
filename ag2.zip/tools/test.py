
import openpyxl
from strands import tool

@tool
def counter(word: str, letter: str):
    """
    指定された単語(word)の中で、指定された文字(letter)が出現する回数をカウントして返す関数。

    Args:
        word (str): 対象の単語
        letter (str): カウントしたい文字

    Returns:
        int: 単語中の文字の出現回数
    """
    return word.lower().count(letter.lower())


@tool
def read_cell_value(cell_position):
    """
    指定されたセル位置(cell_position)の値をExcelファイル('a.xlsx')のSheet1から読み取って返す関数。

    Args:
        cell_position (str): セルの位置（例: 'A1', 'B5'）

    Returns:
        セルに格納されている値（型はセルの内容による）
    """
    # Excelファイルを読み込む
    wb = openpyxl.load_workbook('a.xlsx')
    # Sheet1を取得
    sheet = wb['Sheet1']
    # 指定されたセルの値を取得
    value = sheet[cell_position].value
    # 値を返す
    return value





import json

@tool
def read_meibo():
    """
    名簿が記載された、Excelファイル('名簿.xlsx')のSheet1の全データを読み込み、
    1行目をヘッダーとして2行目以降のデータを辞書のリストに変換し、
    JSON形式の文字列として返す関数。

    Returns:
        str: 名簿が記載されたシートの全データをJSON文字列に変換したもの（日本語文字も正しく表示）
    """
    # Excelファイルを読み込む
    wb = openpyxl.load_workbook('名簿.xlsx')
    # Sheet1を取得
    sheet = wb['Sheet1']
    # 1行目をヘッダーとして取得
    headers = [cell.value for cell in sheet[1]]
    # 2行目以降のデータを取得し、辞書のリストに変換
    data = []
    for row in sheet.iter_rows(min_row=2, values_only=True):
        row_dict = {headers[i]: row[i] for i in range(len(headers))}
        data.append(row_dict)
    # JSON文字列に変換して返す
    return json.dumps(data, ensure_ascii=False, indent=2)


if __name__ == '__main__':
    value = read_cell_value('B5')
    print(f"Sheet1 { 'B5' }セルの値: {value}")

    # 新関数の動作確認
    json_data = read_meibo()
    print("Sheet1の全データ(JSON):")
    print(json_data)
